function Order(){
    return(
        <div className="order_data">
            <div className="State">
            
            <ul><li id="content" className="name"><b>Status</b></li>
            <li>In Progress</li></ul>
            </div>
            <div className="State">
            <ul id="content"><li className="name" ><b>Door</b></li>
            <li>Mark</li></ul>
            </div>
            <div className="State">
            <ul id="content"><li className="name" ><b>Time</b></li>
            <li>10:30< font color="grey"> (24-06-2022)</font> </li></ul>
            </div>
            
        

        </div>
    )
}
export default Order;