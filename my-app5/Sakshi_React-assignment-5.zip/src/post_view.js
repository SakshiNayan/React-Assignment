const Post_view =()=>{
    return(
        <>Post</>
    )
}
export default Post_view;